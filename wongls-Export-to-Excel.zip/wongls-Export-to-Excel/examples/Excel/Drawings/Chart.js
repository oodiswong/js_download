define(['underscore', '../util'], function (_) {
    "use strict";
    var Chart = function () {
        
    };
    _.extend(Chart.prototype, {
        
    });
    return Chart;
});